//
//  ViewController.swift
//  C8
//
//  Created by MacBook on 12/03/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var datos = ["Juana", "David", "Antonio", "Felipe", "Daniela","Juana", "David", "Antonio", "Felipe", "Daniela","Juana", "David", "Antonio", "Felipe", "Daniela","Juana", "David", "Antonio", "Felipe", "Daniela"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identier = "celda"
        let cell = tableView.dequeueReusableCell(withIdentifier: identier, for: indexPath)
        
        cell.textLabel?.text = datos[indexPath.row]
        if indexPath.row % 2 == 0{
            cell.backgroundColor = .blue
        }else {
            cell.backgroundColor = .magenta
        }
        if cell.accessoryType.rawValue == 3{
            cell.accessoryType = .none
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let miclosure = { (action: UIAlertAction) -> Void in
            print("Clicked")
        }
        
        let palomitaclosure = { (action: UIAlertAction) -> Void in
            
            let celda = tableView.cellForRow(at: indexPath)
            if let palomita = celda?.accessoryType.rawValue{
                if palomita == 3{
                    celda?.accessoryType = .none
                }else {
                    celda?.accessoryType = .checkmark
                }
            }
        }
    
        
        let optionmenu = UIAlertController(title: "Alumnos", message: "Esta es una lista de estudiantes", preferredStyle: .alert)
        
        let cancelaction = UIAlertAction(title: "Salir de aquí", style: .cancel, handler: palomitaclosure)
        
        let okaction = UIAlertAction(title: "Ah, ok", style: .default, handler: miclosure)
        
        optionmenu.addAction(cancelaction)
        optionmenu.addAction(okaction)
        present(optionmenu, animated: true, completion: nil)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
    }

}
