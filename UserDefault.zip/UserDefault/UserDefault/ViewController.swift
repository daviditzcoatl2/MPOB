//
//  ViewController.swift
//  UserDefault
//
//  Created by macbook on 09/04/18.
//  Copyright © 2018 potato labs mx. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textBox: UITextField!
    
    var valores = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if let info = valores.object(forKey: "informacion"){
            textBox.text = info as! String
            var cadenaMagica = info as! String
            if cadenaMagica == "segunda"{
                //shouldPerformSegue(withIdentifier: "segundaVista", sender: self)
                performSegue(withIdentifier: "segundaVista", sender: self)
            }
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        print("Ejecutando el segue")
        return true
    }

    @IBAction func guardarInfo(_ sender: Any) {
        let info = textBox.text
        
        if info != ""{
            //UserDefault permite almacenar y manipular info dentro de la aplicacion
            valores.set(info, forKey: "informacion")
        }
        performSegue(withIdentifier: "terceraVista", sender: self)
    }
    

}

