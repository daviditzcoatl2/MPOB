//
//  SegundaViewController.swift
//  UserDefault
//
//  Created by MacBook on 11/04/18.
//  Copyright © 2018 potato labs mx. All rights reserved.
//

import UIKit

class SegundaViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func logout(_ sender: UIButton) {
        UserDefaults.standard.set("", forKey: "informacion")
        navigationController?.popViewController(animated: true) //regresa a la vista anterior 
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
