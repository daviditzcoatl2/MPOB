//
//  ViewController.swift
//  Tarea1
//
//  Created by MacBook on 05/03/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var suma: UIButton!
    @IBOutlet weak var resta: UIButton!
    @IBOutlet weak var N1: UITextField!
    @IBOutlet weak var N2: UITextField!
    @IBOutlet weak var Resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func Sumar(_ sender: UIButton) {
        if (N1 == nil) && (N2 == nil){
            Resultado.text = "Inserta dos numeros"
        }else{
            let x = Int(N1.text!)!
            let y = Int(N2.text!)!
            Resultado.text = String(x+y)
        }
    }
    @IBAction func Resta(_ sender: UIButton) {
        if (N1 == nil) && (N2 == nil){
            Resultado.text = "Inserta dos numeros"
        }else{
            let x = Int(N1.text!)!
            let y = Int(N2.text!)!
            Resultado.text = String(x-y)
        }
    }
}
