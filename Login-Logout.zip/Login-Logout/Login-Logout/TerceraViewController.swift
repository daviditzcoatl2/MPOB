//
//  TerceraViewController.swift
//  Login-Logout
//
//  Created by MacBook on 19/04/18.
//  Copyright © 2018 MacBook7. All rights reserved.
//

import UIKit

class TerceraViewController: UIViewController {
    
    @IBOutlet weak var nombreReg: UITextField!
    @IBOutlet weak var apellidoReg: UITextField!
    @IBOutlet weak var usuarioReg: UITextField!
    @IBOutlet weak var passwordReg: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    //Funcion que verifica que no haya campos vacios y crea nuevos usuarios
    
    @IBAction func hacerRegistro(_ sender: Any) {
        if (nombreReg.text == "" || apellidoReg.text == "" || usuarioReg.text == "" || passwordReg.text == "") {
            showDatosIncompletos()}
        else{
            var nuevoUsuario = Usuario(nombre: nombreReg.text!, apellido: apellidoReg.text!, usuario: usuarioReg.text!, password: passwordReg.text!)
            usuarios.append(nuevoUsuario)
            print(usuarios)
        }
    }

    
    func showDatosIncompletos(){
        let errorAlert = UIAlertController(title: "Error", message: "Los datos no estan completos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Regresar", style: .cancel, handler: nil)
        
        errorAlert.addAction(okAction)
        
        present(errorAlert, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
