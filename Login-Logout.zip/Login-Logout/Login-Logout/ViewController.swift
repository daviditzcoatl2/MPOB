//
//  ViewController.swift
//  Login-Logout
//
//  Created by MacBook on 19/04/18.
//  Copyright © 2018 MacBook7. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usuarioText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Login(_ sender: UIButton) {
        var validate: Bool = true
        if let userName = usuarioText.text, let password = passwordText.text{
            for user in usuarios{
                if userName == user.usuario, password == user.password{
                    print("Usuario validado")
                    shouldPerformSegue(withIdentifier: "vista2", sender: self)
                    break
                }else{
                    validate = false
                }
            }
        }
        
        if !validate{
            showError()
        }
    }
    
    @IBAction func Register(_ sender: UIButton) {
        shouldPerformSegue(withIdentifier: "vista3", sender: self)
    }
    
    func showError(){
        let errorAlert = UIAlertController(title: "Error", message: "Sus datos no son correctos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        
        errorAlert.addAction(okAction)
        
        present(errorAlert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "vista2"{
            print("Ejecutando el nextSegue")
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "vista2" || identifier == "vista3" || identifier == "regreso"{
            return true
        }
        else{
            return false
        }
    }
    
    
    
}

