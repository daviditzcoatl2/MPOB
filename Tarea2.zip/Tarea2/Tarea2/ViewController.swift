//
//  ViewController.swift
//  Tarea2
//
//  Created by MacBook on 05/03/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var deslizador: UISlider!
    @IBOutlet weak var Clima: UILabel!
    @IBOutlet weak var TiempoAtmosférico: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func ClimaSlider(_ sender: UISlider) {
        var x: Float
        x = deslizador.value

        switch x {
        case 1...26:
            Clima.text = "Lluvioso"
            TiempoAtmosférico.image = UIImage (named: "Llvuia")
            
        case 26...50:
            Clima.text = "Nublado"
            TiempoAtmosférico.image = UIImage (named: "Nublado")
            
        case 50...75:
            Clima.text = "Despejado"
            TiempoAtmosférico.image = UIImage (named: "Despejado")
            
        default:
            Clima.text = "Soleado"
            TiempoAtmosférico.image = UIImage (named: "SOLEADO")

            
        }
        
    }
    

}

